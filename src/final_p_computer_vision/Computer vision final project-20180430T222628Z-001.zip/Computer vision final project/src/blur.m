function [ result ] = blur( input , filter)
%BLUR this function blures images by applying a mean filter
%   insert the input image , and spicify the average window size, and the
%   result would be a blured version of the input image. Note: the filter
%   size represent the size of a square window that passes over the image.
%   This function works with odd numbers only for the filter size.

%get the dimention of the input signal and filter
[row,col]=size(input);
[r,c]=size(filter);
%disatnce from the middle to the end of the filter
dis= fix(r/2);
%zero padding the input image
mod_input=cat(1,zeros(dis,col+2*dis),cat(2,zeros(row,dis),input,zeros(row,dis)),zeros(dis,col+2*dis));

%convolving the padded input 
[row,col]=size(mod_input);
result=zeros(row-2*dis,col-2*dis);

for n=dis+1:row-dis
    for m=dis+1:col-dis
        for i=-dis:dis
            for j=-dis:dis
                result(n-dis,m-dis)=result(n-dis,m-dis)+mod_input(n+i,m+j)*filter(i+dis+1,j+dis+1);
            end
        end
    end
end

end


